# gingerurdf

ginger urdf file with joint limit
